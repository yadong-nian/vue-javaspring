package com.god.microserviceusermanagement.model;

public enum Role {
    USER,
    ADMIN
}
