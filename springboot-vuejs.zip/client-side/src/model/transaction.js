export default class Transaction {
    constructor(userId, course, dateOfIssue, id) {
        this.userId = userId;
        this.course = course;
        this.dateOfIssue = dateOfIssue;
        this.id = id;
    }
}